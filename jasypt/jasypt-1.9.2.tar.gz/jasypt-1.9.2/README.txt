
 JASYPT: Java Simplified Encryption
 ----------------------------------
 
 Jasypt (Java Simplified Encryption) is a java library which allows the
 developer to add basic encryption capabilities to his/her projects with
 minimum effort, and without the need of having deep knowledge on how 
 cryptography works.
 
 To learn more and download latest version:
 
     http://www.jasypt.org

     